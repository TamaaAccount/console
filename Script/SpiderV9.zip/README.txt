THANKS TO:
1. 𝕶𝖎𝖓𝖌 𝕾𝖆𝖒 (t.me/The_Chosen_001)
2. 𝗕𝘂𝘆𝗲𝗿